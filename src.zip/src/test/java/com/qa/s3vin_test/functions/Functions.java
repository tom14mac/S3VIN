package com.qa.s3vin_test.functions;
import org.openqa.selenium.*;
import java.util.List;
public class Functions {
    public WebDriver driver;

    public Functions(WebDriver driver) {
        driver = this.driver;
    }
    public WebElement jsclick(WebDriver driver,WebElement element){
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", element);
        return element;
    }
}
