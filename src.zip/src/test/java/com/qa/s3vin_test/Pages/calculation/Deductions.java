package com.qa.s3vin_test.Pages.calculation;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

// page_url = about:blank
public class Deductions{
    public static WebDriver driver;
    public float Grp_pay;

    public Deductions(WebDriver driver) {
        super();
        PageFactory.initElements(driver, this);
    }
    String URL = "http://7.ustaxandpayrollservices.com/staging/public/admin/customers/profile/110/13";
    @FindBy(xpath = "//div[@class='title text-primary kt-font-bolder']")WebElement paystub_employee_nm;
    @FindBy(css = ".title.text-left")WebElement Emp_SSN;
    @FindBy(css = "body > div:nth-child(3) > div:nth-child(1) > div:nth-child(3) > div:nth-child(2) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > table:nth-child(1) > tbody:nth-child(2) > tr:nth-child(1) > td:nth-child(2)")
    WebElement Deductions;
    // Employee gets Deduction plan
    @FindBy(xpath = "//span[normalize-space()='All Employees']")WebElement all_Employees;
    @FindBy(xpath = "//i[@class='la la-filter']")WebElement Emp_filter;
    @FindBy(xpath = "//i[@class='la la-search btn-icon mr-1 mt-2']")WebElement Search_icon;
    @FindBy(css = "html > body > div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(2) > div:nth-of-type(1) > div > div:nth-of-type(2) > div > div > div > table > tbody > tr > td:nth-of-type(3) > div > div > button > div > div > div")
    WebElement select_customer;
    @FindBy(xpath = "//input[@placeholder='Customer Name']")WebElement input_search_box;
    @FindBy(xpath = "//input[@class='form-control invoice_search_keyword filter-keyword-search-input']")WebElement input_general_search;
    @FindBy(xpath = "//tr[@class='odd active']//label[@for='radiobutton']")WebElement Emp_select;
    @FindBy(xpath = "//a[text()='R Industries']")WebElement getSelect_customer;
    @FindBy(xpath = "//a[@data-id=\"13\"]")WebElement Emp_tab;
    @FindBy(xpath = "//*[@id=\"employeeList\"]/tbody/tr[1]/td[2]/div/label")WebElement getGetSelect_Employee;
    @FindBy(xpath = "(//a[normalize-space()='Mario'])[1]")WebElement Emp_view;
    @FindBy(xpath = "//a[contains(text(),'Misc Deductions')]")
    WebElement Misc_Deductiobns;
    @FindBy(xpath = "//a[normalize-space()='Garnishments']")WebElement Garnishment;
    @FindBy(xpath = "//div[@id='heading16995']//span[@class='kt-switch kt-switch--sm kt-switch--custom']//span")
    WebElement switch_status;
    @FindBy(xpath = "/html/body/div[6]/div/div[3]/button[1]")WebElement yes_Deactivate_it;
    @FindBy(xpath = "//button[normalize-space()='OK']")WebElement ok_btn;
    @FindBy(xpath = "(//*[name()='svg'][@class='kt-svg-icon'])[1]")WebElement view_garnishment_plan;
    @FindBy(xpath = "//body/div[@id='overflowW4form']/div[@class='kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page']/div[@id='kt_wrapper']/div[@id='kt_content']/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]")
    WebElement GP05;
    @FindBy(xpath = "//label[normalize-space()='10.00%']")
    WebElement Garnishment_Percentage;

    public void check_deductions(){
        System.out.println(Deductions.getText());
    }
    public WebElement getPaystub_employee_nm() {
        return paystub_employee_nm;
    }
    public void setPaystub_employee_nm(WebElement paystub_employee_nm) {
        this.paystub_employee_nm = paystub_employee_nm;
    }
    public WebElement getEmp_SSN() {
        return Emp_SSN;
    }
    public void setEmp_SSN(WebElement emp_SSN) {
        Emp_SSN = emp_SSN;
    }
    public void get_Emp_detail(){
        paystub_employee_nm.getText();
        Emp_SSN.getText();
        System.out.println(Emp_SSN.getText());
    }
    public void get_deduction_plan() throws InterruptedException {
        String str =String.valueOf(Emp_SSN.getText()).substring(5);
        all_Employees.click();
        Emp_filter.click();
        select_customer.click();
        Thread.sleep(100);
        input_search_box.sendKeys("R industries",Keys.ENTER);
        Search_icon.click();
        Thread.sleep(1000);
        input_general_search.sendKeys("testing",Keys.ENTER);
        input_general_search.clear();
        input_general_search.sendKeys(str);
    }
    public void get_Employee_deductionPlan() throws InterruptedException {
        Thread.sleep(1000);
        getSelect_customer.click();
        Emp_tab.click();
        getGetSelect_Employee.click();
        Emp_view.click();
    }
    public void check_Garnishment_status() throws InterruptedException {
        // DeActivation
        Thread.sleep(1000);
        Garnishment.click();
        Thread.sleep(100);
        switch_status.click();
        Thread.sleep(100);
        yes_Deactivate_it.click();
        Thread.sleep(100);
        ok_btn.click();
        //Activation
        Thread.sleep(1000);
        Garnishment.click();
        Thread.sleep(100);
        switch_status.click();
        Thread.sleep(100);
        yes_Deactivate_it.click();
        Thread.sleep(100);
        ok_btn.click();
    }
    public void get_Employee_Garnishment() throws NumberFormatException, InterruptedException {
       // System.out.println(GP05.getText());
        Thread.sleep(1000);
        Garnishment.click();
        Thread.sleep(1000);
        view_garnishment_plan.click();
        Hours_Earning_cal hoursEarningCal = new Hours_Earning_cal(driver);
        String Garnishment_percentage_S = Garnishment_Percentage.getText();
        System.out.println("Garnishment percentage 0 ="+Garnishment_Percentage.getText());
        System.out.println("Garnishment_percentage 1 ="+Garnishment_percentage_S.toString());
        Garnishment_percentage_S = Garnishment_percentage_S.replace("%","");
        System.out.println("Garnishment_percentage 2 ="+Garnishment_percentage_S);
        System.out.println("Testing check print values from Web element : "+Garnishment_Percentage.getText());
        System.out.println("Testing Garnishment_percentage : "+Garnishment_percentage_S);
        Float check_percentage =  Float.parseFloat(Garnishment_percentage_S.replace("%",""));
        System.out.println("Float = "+check_percentage);
        System.out.println("Garnishment Percentage"+Garnishment_percentage_S);
        System.out.println(hoursEarningCal.Gross_pay_calculation());
    }
}