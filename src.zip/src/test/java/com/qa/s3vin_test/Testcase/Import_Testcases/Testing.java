package com.qa.s3vin_test.Testcase.Import_Testcases;

import com.qa.s3vin_test.Pages.LTS_PayDataTestBase;
import com.qa.s3vin_test.Pages.LTS_PreviewCalculation_TestBase;
import com.qa.s3vin_test.Pages.Loginpage_TestBase;
import com.qa.s3vin_test.Pages.Payroll_LTS_TestBase;
import com.qa.s3vin_test.Pages.calculation.Deductions;
import com.qa.s3vin_test.Pages.calculation.Hours_Earning_cal;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class Testing {
    public WebDriver driver = new ChromeDriver();
    Hours_Earning_cal hoursEarningCal= new Hours_Earning_cal(driver);
    Deductions deductions = new Deductions(driver);

    LTS_PreviewCalculation_TestBase ltsPreviewCalculationTestBase = new LTS_PreviewCalculation_TestBase(driver);
    Loginpage_TestBase loginpageTestBase = new Loginpage_TestBase(driver);
    Payroll_LTS_TestBase payrollLtsTestBase = new Payroll_LTS_TestBase(driver);

    LTS_PayDataTestBase lts_payDataTestBase = new LTS_PayDataTestBase(driver);

    LTS_PreviewCalculation_TestBase  ltsPreviewCalculationTestbase = new LTS_PreviewCalculation_TestBase(driver);


    @Test(priority = 0)
    public void getLoginpageTestBase() {
        driver.get(loginpageTestBase.URL());
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        loginpageTestBase.check_valid_credentials("user1@ustaxandpayrollservices.com","2ytptkr3Gd");
    }

    @Test(priority = 1)
    public void getpayroll() throws InterruptedException {
       /* payrollLtsTestBase.setCompany_name();
        payrollLtsTestBase.setCustomer_name();
        payrollLtsTestBase.setPayroll_tab();
        lts_payDataTestBase.SelectTimesheet("03/08/2023");
        lts_payDataTestBase.Calculate_Payroll();
        lts_payDataTestBase.setCalculate_Payroll();*/
    }

    @Test(priority = 2)
    public void getLtsPreviewCalculationTestBase() throws InterruptedException {
      /*  lts_payDataTestBase.check_Approve_calculate_payroll_Emp();
        ltsPreviewCalculationTestbase.Preview_Calculation_get_details();
        ltsPreviewCalculationTestbase.Employee_list();
        ltsPreviewCalculationTestbase.get_Employee_Paystub_details();*/
        driver.navigate().to("http://7.ustaxandpayrollservices.com/staging/public/admin/company/generate-payroll/110?_token=gz47GIQmaZ7g2rKlpYPrl4NOE5t7UHfVPCqBAhUS&selectedPayPeriod=3164&companyOnboardingId=110&active_tab_name=LTS&profile_tab=paydata&type=lts");
        Thread.sleep(1000);
        ltsPreviewCalculationTestBase.get_Employee_Paystub_details();
        ltsPreviewCalculationTestBase.Preview_Calculation_get_details();
        Thread.sleep(1000);
        driver.navigate().to("http://7.ustaxandpayrollservices.com/staging/public/admin/customer/employee/profile-tab/195128/0");
        driver.navigate().to("http://7.ustaxandpayrollservices.com/staging/public/admin/customer/employee/profile-tab/195128/1");
        //deductions.check_Garnishment_status();
        deductions.get_Employee_Garnishment();
    }
}
