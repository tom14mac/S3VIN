package com.qa.s3vin_test.Testcase;

import com.qa.s3vin_test.Pages.LTS_PreviewCalculation_TestBase;
import com.qa.s3vin_test.Pages.calculation.Deduction_TestBase;
import com.qa.s3vin_test.Pages.calculation.Hours_Earning_cal;
import io.qameta.allure.Allure;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;

public class LTS_Payroll_Step3 extends LTS_Payroll_Step2{
    LTS_PreviewCalculation_TestBase ltsPreviewCalculationTestbase = new LTS_PreviewCalculation_TestBase(driver);
    Hours_Earning_cal hoursEarningCal =new Hours_Earning_cal(driver);
    Deduction_TestBase deductions = new Deduction_TestBase(driver);
    @Override
    public void Verify_page_Refresh() throws InterruptedException {
        super.Verify_page_Refresh();
         Thread.sleep(10000);
         driver.getCurrentUrl();
         driver.getTitle();
    }
    @Test(priority = 20,alwaysRun = true)
    public void get_Employee_list_details() throws InterruptedException {
    ltsPreviewCalculationTestbase.Preview_Calculation_get_details();
    ltsPreviewCalculationTestbase.Employee_list();
   // ltsPreviewCalculationTestbase.view_uapproved();
    //Creating object of an Actions class
        Actions action = new Actions(driver);
        //Performing the mouse hover action on the target element.
        //action.moveToElement(ltsPreviewCalculationTestbase.getEye_icon_unapproved()).perform();
        //ltsPreviewCalculationTestbase.Download_Reset_Payroll();
    }
    @Test(description = "",priority = 21)
    public void Check_getEmployee_Paystub() throws InterruptedException {
        ltsPreviewCalculationTestbase.get_Employee_Paystub_details();
        Allure.addAttachment("updated Successfully", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
    }
    @Test(priority = 22)
    public void check_store_values() throws InterruptedException {
    ltsPreviewCalculationTestbase.Emp_list_switch();
    driver.navigate().refresh();
    Thread.sleep(10000);
        ArrayList<String> tabs1 = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs1.get(1));
        js.executeScript("window.scrollBy(0,450)", "");
        //objAdd.setTimesheet_details();
        hoursEarningCal.setTimesheet_details();
        driver.switchTo().window(tabs1.get(1)).close();
        driver.switchTo().window(tabs1.get(0));
        ltsPreviewCalculationTestbase.getEmp_paystub_tab_click();
    }
    @Test(priority = 23)
    public void check_calculation(){
        hoursEarningCal.setTimesheet_calculation();
        hoursEarningCal.VerifiedPrint_values();
        hoursEarningCal.Gross_pay_calculation();
       //Assert.assertEquals(hoursEarningCal.get_gorssPay(),hoursEarningCal.getPaystub_GrossPay().getText().substring(1));
    }
    @Test(priority = 24)
    public void Verify_Deductions() throws InterruptedException {
     deductions.check_deductions();
     deductions.get_Emp_detail();
     //deductions.get_deduction_plan();
        Thread.sleep(1000);
     deductions.get_Employee_deductionPlan();
    }
    @Test(priority = 25)
    public void Verify_GarnishmentPlan() throws InterruptedException,NumberFormatException {
      deductions.check_Garnishment_status();
      deductions.get_Employee_Garnishment();
    }
    @Test(priority = 26)
    public void check_Total_Employee_Taxes(){

    }
    @Test(priority = 26)
    public void check_Details(){

    }
    @Test(priority = 27)
            public void check_Paid_Time_off(){
    }
    @Test(priority = 28)
    public void get_Employer_Contributions(){

    }
    @Test(priority = 29)
    public void Total_calculation_Employer_Contributions(){

    }
    @Test(priority = 30)
    public void get_Employee_Taxes2(){

    }
    @Test(priority = 31)
    public void Total_calculation_Employee_Taxes(){

    }
    @Test(priority = 32)
    public void Recalculation_check(){}
}
